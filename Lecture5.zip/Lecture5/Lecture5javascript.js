var database=[
    {
        username:"Ali",
        password:"123"
    }
];

var newsfeed = [
{username:"Fahad",
timeline:"JAVA Scriptis important"
},{
    username:"farooq",
    timeline:"JAVA Script is BORING"
}
];

var userNamePrompt=prompt("whats is your name?");
var passwordPrompt=prompt("what is your password");

function signIn(user,pass){
    if(user===database[0].username && pass=== database[0].password){
        console.log(newsfeed);
    }else{
        alert("wrong id and password");
    }
}



